英単語バトル Firebase接続済み版

1. Firebaseプロジェクト english-battle-f2329 に接続する設定を組み込みました。
2. Firebase Authentication の「匿名」を有効化してください。
3. Realtime Database の「ルール」に同梱の rules.json を設定し「公開」してください。
4. Netlify にこのZIPを展開した english-battle フォルダを公開してください。
5. 2台のスマホでURLを開き、ルームを作成・参加してください。

重要: 同梱ルールは開発テスト用です。参加者によるスコアや出題情報の改変を十分防げません。一般公開・ランキング運用にはサーバー側で採点と早押しの判定を実装してください。
