1. GitHub repository english-battle の index.html を上書き
2. Firebase Realtime Database > ルールに firebase-rules.json 全文を貼り付け「公開」
3. Chrome通常タブで部屋を作り、シークレットタブで参加
注意: テスト用の実装です。実際のFirebase接続は未検証です。
